<!-- <?php // require_once "header.php"; ?> -->

<h2>Cadastro</h2>
<form action="#" method="post">

    <label for="nome_completo_ou_restaurante">Nome completo / Nome do Restaurante </label>
    <input type="text" name="nome_aluno" id="nome_aluno"><br><br>

    <label for="email_">Email </label>
    <input type="text" name="email_aluno" id="email_aluno"><br><br>

    <label for="celular_aluno">Senha </label>
    <input type="text" name="celular_aluno" id="celular_aluno"><br><br>

    <input type="submit" value="Cadastrar Aluno"><br><br>
    
</form>
<a href="index.php"><img src="images\icons\back.png" alt=""></a>
<?php require "footer.php"; ?>