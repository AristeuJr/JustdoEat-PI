
<img src="images\icons\logo_justdoeat.png" alt="Logo"><br>

<h4>Entre com a sua conta para realizar pedidos!</h4>

<form action="login_user.php" method="post">
    <label for="login_user">Insira o E-mail </label>
    <input type="text" name="login_user" id="login_user"><br><br>
    <label for="password">Insira a Senha </label>
    <input type="password" name="password_user" id="password_user"><br><br>
    <input type="submit" value="Entrar">
</form>
<p><a href="form_cadastro.php">Criar conta</a></p>
<p><a href="#">Esqueceu a senha?</a></p>
<?php
    //Inicia a sessão em PHP
    session_start();
    //Verifica se existe alguma informação na sessão
    if(isset($_SESSION['mensagem']))
    {
        //Armazena a mensagem em uma váriavel para impressão
        $mensagem = $_SESSION['mensagem'];
        //Imprime na tela a mensagem
        echo "<p>" . $mensagem . "<p>";

        //Retira a informação recebida da sessão
        unset($_SESSION['mensagem']);
     }
?>

<?php include "footer.php"; ?>