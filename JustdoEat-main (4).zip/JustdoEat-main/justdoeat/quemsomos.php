<?php
    include "header.php";
?>
<div class="about-us-container">
    <div class="container content-grid">
        <div class="mission-section">
            <h1>Qual a Nossa Missão?</h1>
            <p>
                 Atender o máximo de pessoas que buscam alimentos de qualidade, com a praticidade de um clique, atendendo também uma parcela vulnerável da sociedade.
            </p>
        <div class="slogan-section">
            <img src="images/icons/logo_justdoeat.png" alt="Logo Just do Eat">
            <h2>Quando quiser, onde estiver.</h2>
        <div class="ods-section">
            <h2>Quais ODS's Atendemos?</h2>
            <ul>
            <li>2 – Fome Zero; </li>
            <li>3 – Boa Saúde e Bem-estar; </li>
            <li>9 – Industria, inovação e infraestrutura.</li>
            </ul>
        <div class="objetivos-section">
        <img src="images/icons/objetivos_port 1.png" alt="Objetivos de Desenvolvimento">
        </div>
</div>
<?php
    include "footer.php";
?>