</main>
    <footer>
        <div class="container">
            <div class="footer-logo">
                <img src="/justdoeat/images/icons/logo_justdoeat.png" alt="Logo Just Do Eat">
            </div>
            <div class="footer-links">
                <h4>Just Do Eat</h4>
                <ul>
                    <li><a href="/justdoeat/quemsomos.php">Quem Somos Nós</a></li>
                    <li><a href="#">Carreiras</a></li>
                    <li><a href="#">Instituições Parceiras</a></li>
                </ul>
            </div>
            <div class="footer-links">
                <h4>Descubra</h4>
                <ul>
                    <li><a href="registro.php">Cadastre Seu Restaurante</a></li>
                    <li><a href="#">Seja Nosso Entregador!</a></li>
                    <li><a href="quemsomos.php">ODS's</a></li>
                </ul>
            </div>
            <div class="footer-social">
                <h4>Social</h4>
                  <a href="https://www.facebook.com"><img src="/justdoeat/images/icons/facebook_icon.png" alt="Facebook"></a>
                  <a href="https://www.instagram.com"><img src="/justdoeat/images/icons/instagram_icon.png" alt="Instagram"></a>
                  <a href="https://www.whatsapp.com"><img src="/justdoeat/images/icons/whatsapp_icon.png" alt="WhatsApp"></a>
            </div>
        </div>
        <div class="copyright">
            <p>&copy; Copyright 2025 - Just Do Eat - Todos os direitos reservados Just do Eat S.A.</p>
        </div>
    </footer>
</body>
</html>